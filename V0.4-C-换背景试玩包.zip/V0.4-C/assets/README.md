# 美术资源替换接口

`config.js` 的 `assets` 表是唯一资源入口。正式素材按下列目录放置并保持透明背景/统一锚点即可，游戏逻辑无需修改。

- `characters/player-idle.png`、`player-meditating.png`：青衫书生
- `enemies/enemy-walk.png`、`enemy-attack.png`、`enemy-defeated.png`：夜行鬼
- `buildings/bed-lv1.png` ～ `bed-lv4.png`：聚灵床各等级
- `buildings/door-lv1.png` ～ `door-lv4.png`：镇魂门各等级
- `buildings/turret-lv1.png` ～ `turret-lv3.png`：镇妖弩各等级
- `ui/room-background.png`：房间背景
- `ui/corridor-background.png`：走廊背景
- `ui/spirit-stone.png`：灵石图标
- `ui/icon-pause.png`、`icon-upgrade.png`：当前已裁切 UI 图标；其他图标缺失时保留文字占位
- `effects/spirit-bolt.png`、`hit-effect.png`：符箭和命中；缺失时 Canvas 使用发光圆点
- `audio/`：后续音效（V0.2 技术骨架未接入音频）

资源不存在时，页面自动使用当前 CSS 几何占位，不会阻断游戏运行。
