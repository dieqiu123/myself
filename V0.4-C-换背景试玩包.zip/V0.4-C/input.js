(function () {
  'use strict';

  const game = window.mgdGame;

  document.getElementById('bed').addEventListener('click', () => game.select('bed'));
  document.getElementById('door').addEventListener('click', () => game.select('door'));
  document.getElementById('turretSlots').addEventListener('click', (event) => {
    const slot = event.target.closest('[data-slot]');
    if (!slot) return;
    const index = Number(slot.dataset.slot);
    game.select(game.getSlotSelectionType(index), index);
  });
  document.getElementById('buildTypeSelect').addEventListener('change', (event) => game.setBuildChoice(event.target.value));
  document.getElementById('mainAction').addEventListener('click', () => game.performSelectedAction());
  document.getElementById('pauseButton').addEventListener('click', () => game.togglePause());
  document.getElementById('restartButton').addEventListener('click', () => game.restart());
})();
