(function () {
  'use strict';

  window.GAME_CONFIG = Object.freeze({
    preparationSeconds: 20,
    enemyApproachSeconds: 8,
    enemy: Object.freeze({
      maxHp: 220,
      doorDamagePerSecond: 5,
      turretRangeProgress: 0.32,
      woundedThreshold: 0.4,
      woundedFeedbackSeconds: 0.9,
      retreatSpeedMultiplier: 1.65,
      waveCount: 3,
      waves: Object.freeze([
        Object.freeze({ hp: 220, doorDamagePerSecond: 5, moveSpeedMultiplier: 1 }),
        Object.freeze({ hp: 300, doorDamagePerSecond: 7, moveSpeedMultiplier: 1.1 }),
        Object.freeze({ hp: 380, doorDamagePerSecond: 10, moveSpeedMultiplier: 1.2 })
      ]),
      killReward: 24,
      retreatReward: 8,
      waveIntermissionSeconds: 2.4
    }),
    bed: Object.freeze([
      Object.freeze({ level: 1, income: 1, upgradeCost: 14 }),
      Object.freeze({ level: 2, income: 2, upgradeCost: 34 }),
      Object.freeze({ level: 3, income: 4, upgradeCost: 72 }),
      Object.freeze({ level: 4, income: 7, upgradeCost: null })
    ]),
    door: Object.freeze([
      Object.freeze({ level: 1, maxHp: 160, upgradeCost: 14 }),
      Object.freeze({ level: 2, maxHp: 280, upgradeCost: 32 }),
      Object.freeze({ level: 3, maxHp: 460, upgradeCost: 68 }),
      Object.freeze({ level: 4, maxHp: 720, upgradeCost: null })
    ]),
    turret: Object.freeze([
      Object.freeze({ level: 1, attack: 4, interval: 1.0, upgradeCost: 26 }),
      Object.freeze({ level: 2, attack: 8, interval: 0.9, upgradeCost: 58 }),
      Object.freeze({ level: 3, attack: 15, interval: 0.8, upgradeCost: null })
    ]),
    turretBuildCost: 12,
    turretZones: Object.freeze({
      front: Object.freeze({ label: '前场', rangeProgress: 0.18, damageMultiplier: 1 }),
      mid: Object.freeze({ label: '中场', rangeProgress: 0.32, damageMultiplier: 1.02 }),
      rear: Object.freeze({ label: '后场', rangeProgress: 0.48, damageMultiplier: 1.04 })
    }),
    auxiliary: Object.freeze({
      lamp: Object.freeze({
        buildCost: 20,
        levels: Object.freeze([
          Object.freeze({ level: 1, income: 1, upgradeCost: 38 }),
          Object.freeze({ level: 2, income: 2, upgradeCost: 76 }),
          Object.freeze({ level: 3, income: 4, upgradeCost: null })
        ])
      }),
      repair: Object.freeze({ buildCost: 14, interval: 2.5, heal: 8, auraCost: 1 }),
      slow: Object.freeze({ buildCost: 18, speedMultiplier: 0.72 })
    }),
    turretSlotCount: 9,
    world: Object.freeze({
      width: 360,
      height: 560,
      grayboxMode: false,
      room: Object.freeze({ x: 62, y: 34, width: 278, height: 492 }),
      corridor: Object.freeze({ x: 0, y: 0, width: 62, height: 560 }),
      door: Object.freeze({ x: 62, y: 405, width: 42, height: 86 }),
      bed: Object.freeze({ x: 219, y: 444, width: 108, height: 68 }),
      // Presentation-only anchors for the supplied scene background. These
      // do not change collision, pathing, damage, or any game-state values.
      // Image-2 playable-layout anchor: the gate fills the lower-left guard
      // entrance; the player and bed retain their existing positions.
      doorVisual: Object.freeze({ x: 82, y: 416, width: 92, height: 112 }),
      bedVisual: Object.freeze({ x: 225, y: 365, width: 104, height: 76 }),
      turretSlots: Object.freeze([
        Object.freeze({ x: 126, y: 126, size: 52, zone: 'front' }),
        Object.freeze({ x: 266, y: 126, size: 52, zone: 'front' }),
        Object.freeze({ x: 196, y: 198, size: 52, zone: 'front' }),
        Object.freeze({ x: 118, y: 274, size: 52, zone: 'mid' }),
        Object.freeze({ x: 194, y: 274, size: 52, zone: 'mid' }),
        Object.freeze({ x: 270, y: 274, size: 52, zone: 'mid' }),
        Object.freeze({ x: 118, y: 366, size: 52, zone: 'mid' }),
        Object.freeze({ x: 194, y: 366, size: 52, zone: 'rear' }),
        Object.freeze({ x: 270, y: 366, size: 52, zone: 'rear' })
      ]),
      enemyPath: Object.freeze([
        Object.freeze({ x: 31, y: 42 }),
        Object.freeze({ x: 31, y: 170 }),
        Object.freeze({ x: 31, y: 355 }),
        Object.freeze({ x: 31, y: 448 }),
        Object.freeze({ x: 82, y: 476 }),
        Object.freeze({ x: 128, y: 476 })
      ])
    }),
    assets: Object.freeze({
      playerSprite: 'assets/characters/player-idle.png',
      playerMeditatingSprite: 'assets/characters/player-meditating.png',
      playerMeditatingCutout: 'assets/characters/player-meditating-cutout.png',
      enemySprite: 'assets/enemies/enemy-walk.png',
      enemyAttackSprite: 'assets/enemies/enemy-attack.png',
      enemyDefeatedSprite: 'assets/enemies/enemy-defeated.png',
      sceneBackground: 'assets/ui/scene-background.png',
      roomBackground: 'assets/ui/room-background.png',
      corridorBackground: 'assets/ui/corridor-background.png',
      spiritIcon: 'assets/ui/spirit-stone.png',
      pauseIcon: 'assets/ui/icon-pause.png',
      upgradeIcon: 'assets/ui/icon-upgrade.png',
      bedLv1: 'assets/buildings/bed-lv1.png',
      bedLv2: 'assets/buildings/bed-lv2.png',
      bedLv3: 'assets/buildings/bed-lv3.png',
      doorLv1: 'assets/buildings/door-lv1.png',
      doorLv2: 'assets/buildings/door-lv2.png',
      doorLv3: 'assets/buildings/door-lv3.png',
      turretLv1: 'assets/buildings/turret-lv1.png',
      turretLv2: 'assets/buildings/turret-lv2.png',
      turretLv3: 'assets/buildings/turret-lv3.png',
      slotEmpty: 'assets/buildings/slot-empty.png',
      turretPedestal: 'assets/buildings/turret-pedestal.png',
      boltSprite: 'assets/effects/spirit-bolt.png',
      hitEffect: 'assets/effects/hit-effect.png'
    })
  });
})();
