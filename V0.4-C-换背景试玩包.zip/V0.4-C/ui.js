(function () {
  'use strict';

  const config = window.GAME_CONFIG;
  const elements = {
    spirit: document.getElementById('spiritValue'),
    incomeRate: document.getElementById('incomeRate'),
    incomeFloat: document.getElementById('incomeFloat'),
    phaseLabel: document.getElementById('phaseLabel'),
    phaseTimer: document.getElementById('phaseTimer'),
    threatChip: document.getElementById('threatChip'),
    waveChip: document.getElementById('waveChip'),
    countdown: document.getElementById('countdown'),
    enemy: document.getElementById('enemy'),
    enemyHealthBar: document.getElementById('enemyHealthBar'),
    doorHealth: document.getElementById('doorHealth'),
    doorHealthBar: document.getElementById('doorHealthBar'),
    doorHealthText: document.getElementById('doorHealthText'),
    bedLevel: document.getElementById('bedLevel'),
    doorLevel: document.getElementById('doorLevel'),
    objectName: document.getElementById('objectName'),
    objectStat: document.getElementById('objectStat'),
    objectHint: document.getElementById('objectHint'),
    sheetArt: document.getElementById('sheetArt'),
    buildTypeControl: document.getElementById('buildTypeControl'),
    buildTypeSelect: document.getElementById('buildTypeSelect'),
    mainAction: document.getElementById('mainAction'),
    pauseButton: document.getElementById('pauseButton'),
    pauseVeil: document.getElementById('pauseVeil'),
    toast: document.getElementById('toast'),
    resultDialog: document.getElementById('resultDialog'),
    resultTitle: document.getElementById('resultTitle'),
    resultMessage: document.getElementById('resultMessage')
  };

  let toastTimer = 0;

  function formatHp(value) {
    return Math.max(0, Math.ceil(value));
  }

  function renderPhase(state) {
    const phaseContent = {
      idle: ['厢房内', '待入定', '妖鬼未现身'],
      preparing: ['准备时间', `${Math.ceil(state.preparationRemaining)}秒`, '妖鬼未现身'],
      enemy_approaching: ['妖鬼接近', `${Math.ceil(state.approachRemaining)}秒`, '夜行鬼进入客栈'],
      combat: [`第 ${state.wave} 波`, '交战中', '夜行鬼正在破门'],
      enemy_wounded: [`第 ${state.wave} 波`, '妖鬼重伤', '停止破门，镇妖弩继续追击'],
      enemy_retreating: [`第 ${state.wave} 波`, '正在撤退', '镇妖弩会追击至离开射程'],
      wave_intermission: [`波次间隔`, `${Math.ceil(state.enemy.intermissionRemaining)}秒`, '夜行鬼暂时退散'],
      victory: ['结算', '胜利', '夜行鬼已退散'],
      defeat: ['结算', '失败', '镇魂门已失守']
    }[state.phase];
    elements.phaseLabel.textContent = phaseContent[0];
    elements.phaseTimer.textContent = phaseContent[1];
    elements.threatChip.textContent = phaseContent[2];
    elements.waveChip.textContent = `第 ${state.wave} 波`;
    elements.countdown.hidden = !['idle', 'preparing'].includes(state.phase);
    elements.countdown.textContent = state.phase === 'idle' ? '点击入定' : Math.ceil(state.preparationRemaining);
  }

  function renderVitals(state) {
    const income = config.bed[state.bed.level - 1].income;
    elements.spirit.textContent = state.spirit;
    elements.incomeRate.textContent = state.phase === 'idle' ? '+0/秒' : `+${income}/秒`;
    elements.incomeFloat.textContent = `+${income}/秒`;
    elements.bedLevel.textContent = `Lv.${state.bed.level}`;
    elements.doorLevel.textContent = `Lv.${state.door.level}`;
    elements.doorHealthText.textContent = `${formatHp(state.door.hp)}/${state.door.maxHp}`;
    elements.doorHealth.setAttribute('aria-valuemax', state.door.maxHp);
    elements.doorHealth.setAttribute('aria-valuenow', formatHp(state.door.hp));
    const doorRatio = state.door.hp / state.door.maxHp;
    elements.doorHealth.classList.toggle('is-warning', doorRatio <= 0.45);
    elements.enemyHealthBar.style.width = `${state.enemy.hp / state.enemy.maxHp * 100}%`;
    elements.enemy.setAttribute('aria-valuenow', formatHp(state.enemy.hp));
  }

  function renderPanel(state) {
    document.querySelectorAll('.is-selected').forEach((node) => node.classList.remove('is-selected'));
    const { type, index } = state.selection;
    elements.buildTypeControl.hidden = true;
    elements.buildTypeSelect.value = 'turret';
    const selected = type === 'bed' || type === 'door'
      ? document.querySelector(`[data-object="${type}"]`)
      : document.querySelector(`[data-slot="${index}"]`);
    if (selected) selected.classList.add('is-selected');

    // The detail card must show the selected game's actual entity, not a
    // permanent bed placeholder. The asset is visual-only and uses the same
    // level clamp as the scene renderer because this build supplies Lv1–Lv3.
    const panelAssetKey = type === 'door'
      ? `doorLv${Math.min(state.door.level, 3)}`
      : type === 'bed'
        ? `bedLv${Math.min(state.bed.level, 3)}`
        : type === 'turret'
          ? `turretLv${Math.min(state.turrets[index].level, 3)}`
          : type === 'slot'
            ? 'turretLv1'
            : 'bedLv1';
    elements.sheetArt.dataset.object = type;
    elements.sheetArt.dataset.level = type === 'door' ? state.door.level : type === 'bed' ? state.bed.level : '';
    elements.sheetArt.style.backgroundImage = `var(--asset-${panelAssetKey})`;

    if (state.phase === 'idle') {
      elements.objectName.textContent = type === 'bed' ? '聚灵床 Lv.1' : '尚未入定';
      elements.objectStat.textContent = type === 'bed' ? '每秒 +1 灵石' : '先从聚灵床开始本局';
      elements.objectHint.textContent = '入定后开始聚灵，并启动 20 秒准备';
      elements.mainAction.textContent = type === 'bed' ? '入定' : '请选择聚灵床';
      elements.mainAction.disabled = type !== 'bed';
      return;
    }

    elements.mainAction.disabled = state.paused || ['victory', 'defeat'].includes(state.phase);
    if (type === 'bed') {
      const current = config.bed[state.bed.level - 1];
      elements.objectName.textContent = `聚灵床 Lv.${state.bed.level}`;
      elements.objectStat.textContent = `每秒 +${current.income} 灵石`;
      elements.objectHint.textContent = current.upgradeCost == null ? '已达到当前版本最高等级' : '升级经济，获得更快的后续发展';
      elements.mainAction.textContent = current.upgradeCost == null ? '已满级' : `升级 ${current.upgradeCost}`;
      elements.mainAction.disabled ||= current.upgradeCost == null;
    } else if (type === 'door') {
      const current = config.door[state.door.level - 1];
      elements.objectName.textContent = `镇魂门 Lv.${state.door.level}`;
      elements.objectStat.textContent = `耐久 ${formatHp(state.door.hp)}/${state.door.maxHp}`;
      elements.objectHint.textContent = current.upgradeCost == null ? '已达到当前版本最高等级' : '升级后恢复到新等级的满耐久';
      elements.mainAction.textContent = current.upgradeCost == null ? '已满级' : `升级并回满 ${current.upgradeCost}`;
      elements.mainAction.disabled ||= current.upgradeCost == null;
    } else if (type === 'slot') {
      const choice = { name: '镇妖弩', stat: '自动攻击进入射程的妖鬼', cost: config.turretBuildCost, currency: '灵石' };
      elements.objectName.textContent = `空建筑位 ${index + 1}`;
      elements.objectStat.textContent = choice.stat;
      elements.objectHint.textContent = `${choice.name}将占用当前建筑格`;
      elements.mainAction.textContent = `建造 · ${choice.cost} ${choice.currency}`;
    } else if (type === 'turret') {
      const turret = state.turrets[index];
      const current = config.turret[turret.level - 1];
      elements.objectName.textContent = `镇妖弩 Lv.${turret.level}`;
      elements.objectStat.textContent = `攻击 ${current.attack} · 自动瞄准`;
      elements.objectHint.textContent = current.upgradeCost == null ? '已达到当前版本最高等级' : '升级后提高攻击力与射击频率';
      elements.mainAction.textContent = current.upgradeCost == null ? '已满级' : `升级 ${current.upgradeCost}`;
      elements.mainAction.disabled ||= current.upgradeCost == null;
    } else if (type === 'lamp') {
      const lamp = state.auxiliaryBuildings[index];
      const current = config.auxiliary.lamp.levels[lamp.level - 1];
      elements.objectName.textContent = `聚灵灯 Lv.${lamp.level}`;
      elements.objectStat.textContent = `每秒 +${current.income} 灵气`;
      elements.objectHint.textContent = current.upgradeCost == null ? '已达到当前版本最高等级' : '升级后提高灵气产量';
      elements.mainAction.textContent = current.upgradeCost == null ? '已满级' : `升级 ${current.upgradeCost} 灵石`;
      elements.mainAction.disabled ||= current.upgradeCost == null;
    } else if (type === 'repair') {
      const repair = config.auxiliary.repair;
      elements.objectName.textContent = '镇魂符台';
      elements.objectStat.textContent = `每 ${repair.interval} 秒消耗 ${repair.auraCost} 灵气，恢复 ${repair.heal} 耐久`;
      elements.objectHint.textContent = '镇魂门满耐久或本局结束时停止维修';
      elements.mainAction.textContent = '自动维修中';
      elements.mainAction.disabled = true;
    } else if (type === 'slow') {
      elements.objectName.textContent = '寒符阵';
      elements.objectStat.textContent = `妖鬼移动速度降低 ${Math.round((1 - config.auxiliary.slow.speedMultiplier) * 100)}%`;
      elements.objectHint.textContent = '不造成伤害，仅影响妖鬼移动';
      elements.mainAction.textContent = '持续生效';
      elements.mainAction.disabled = true;
    }
  }

  function showToast(message) {
    clearTimeout(toastTimer);
    elements.toast.textContent = message;
    elements.toast.classList.add('is-visible');
    toastTimer = setTimeout(() => elements.toast.classList.remove('is-visible'), 1500);
  }

  function renderEvent(state) {
    const messages = {
      insufficient_spirit: '灵石不足，继续聚灵',
      insufficient_aura: '灵气不足，请先建造或升级聚灵灯',
      max_level: '已达到当前版本最高等级',
      fixed_level: '该辅助建筑当前无需升级',
      unique_building_exists: '本局已建造该辅助建筑',
      lamp_built: '聚灵灯已建成，开始产生灵气',
      lamp_upgraded: '聚灵灯升级，灵气产量提高',
      repair_built: '镇魂符台已建成',
      slow_built: '寒符阵已建成，妖鬼移动减缓',
      door_repaired: '镇魂符台恢复镇魂门耐久',
      door_upgraded_full: '镇魂门升级，耐久已回满',
      enemy_spawned: '夜行鬼进入客栈',
      combat_started: '夜行鬼开始攻击镇魂门',
      enemy_wounded: '夜行鬼重伤，停止破门',
      enemy_retreating: '夜行鬼加速逃离，镇妖弩继续追击',
      enemy_killed: `夜行鬼撤退途中被击杀，获得 ${config.enemy.killReward} 灵石`,
      enemy_retreated: `夜行鬼成功逃离，获得 ${config.enemy.retreatReward} 灵石`,
      next_wave_started: '下一波夜行鬼出现',
      must_meditate: '请先点击聚灵床入定'
    };
    if (messages[state.lastEvent]) showToast(messages[state.lastEvent]);
  }

  function renderResult(state) {
    const ended = state.phase === 'victory' || state.phase === 'defeat';
    elements.resultDialog.hidden = !ended;
    if (!ended) return;
    const won = state.phase === 'victory';
    elements.resultTitle.textContent = won ? '镇妖成功' : '镇魂门失守';
    elements.resultMessage.textContent = won ? '夜行鬼已被符箭击退。' : '门的耐久已归零，及时升级可恢复满耐久。';
  }

  function render(state) {
    renderPhase(state);
    renderVitals(state);
    renderPanel(state);
    renderEvent(state);
    renderResult(state);
    elements.pauseButton.disabled = !['preparing', 'enemy_approaching', 'combat', 'enemy_wounded', 'enemy_retreating', 'wave_intermission'].includes(state.phase);
    elements.pauseButton.setAttribute('aria-label', state.paused ? '继续游戏' : '暂停游戏');
    elements.pauseButton.querySelector('span').textContent = state.paused ? '▶' : 'Ⅱ';
    elements.pauseVeil.hidden = !state.paused;
    window.mgdRenderer.render(state);
  }

  window.mgdGame.subscribe(render);
})();
