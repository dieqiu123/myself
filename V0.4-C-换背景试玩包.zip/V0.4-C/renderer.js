(function () {
  'use strict';

  const config = window.GAME_CONFIG;

  class Renderer {
    constructor() {
      this.root = document.getElementById('game');
      this.world = document.getElementById('world');
      this.scene = document.getElementById('scene');
      this.room = document.getElementById('room');
      this.corridor = document.getElementById('corridor');
      this.enemy = document.getElementById('enemy');
      this.canvas = document.getElementById('effectsCanvas');
      this.context = this.canvas.getContext('2d');
      this.loadedAssets = new Map();
      this.lastState = null;
      this.resizeObserver = new ResizeObserver(() => this.resizeCanvas());
      this.resizeObserver.observe(this.world);
      this.resizeCanvas();
      this.applyWorldLayout();
      this.loadAssets();
    }

    loadAssets() {
      Object.entries(config.assets).forEach(([key, source]) => {
        const image = new Image();
        image.onload = () => {
          this.loadedAssets.set(key, image);
          document.documentElement.style.setProperty(`--asset-${key}`, `url("${source}")`);
          this.applyStaticAsset(key);
          // The first UI render happens before images finish loading. Render
          // the current state again so bed/door/player/turret artwork appears
          // immediately instead of waiting for the next user interaction.
          const state = this.lastState || window.mgdGame?.state;
          if (state) this.render(state);
        };
        image.src = source;
      });
    }

    applyStaticAsset(key) {
      if (config.world.grayboxMode && key === 'corridorBackground') return;
      const staticTargets = {
        sceneBackground: this.scene,
        roomBackground: this.room,
        corridorBackground: document.querySelector('.corridor'),
        spiritIcon: document.querySelector('.resource-mark'),
        pauseIcon: document.getElementById('pauseButton'),
        restartIcon: document.getElementById('restartButton')
      };
      const target = staticTargets[key];
      if (target) target.classList.add(`has-${key}`);
    }

    applyWorldLayout() {
      const world = config.world;
      this.scene.classList.toggle('is-graybox', world.grayboxMode);
      this.setWorldRect(this.room, world.room);
      this.setWorldRect(this.corridor, world.corridor);
    }

    setWorldPosition(element, point) {
      element.style.left = `${point.x / config.world.width * 100}%`;
      element.style.top = `${point.y / config.world.height * 100}%`;
      element.dataset.worldX = point.x;
      element.dataset.worldY = point.y;
    }

    setWorldRect(element, rect) {
      this.setWorldPosition(element, rect);
      element.style.width = `${rect.width / config.world.width * 100}%`;
      element.style.height = `${rect.height / config.world.height * 100}%`;
    }

    assetAvailable(key) {
      return !config.world.grayboxMode && this.loadedAssets.has(key);
    }

    getPathPoint(progress) {
      const points = config.world.enemyPath;
      const lengths = [];
      let total = 0;
      for (let index = 1; index < points.length; index += 1) {
        const previous = points[index - 1];
        const point = points[index];
        total += Math.hypot(point.x - previous.x, point.y - previous.y);
        lengths.push(total);
      }
      const target = Math.max(0, Math.min(1, progress)) * total;
      let previousLength = 0;
      for (let index = 1; index < points.length; index += 1) {
        const segmentEnd = lengths[index - 1];
        if (target <= segmentEnd) {
          const start = points[index - 1];
          const end = points[index];
          const ratio = (target - previousLength) / (segmentEnd - previousLength || 1);
          return { x: start.x + (end.x - start.x) * ratio, y: start.y + (end.y - start.y) * ratio };
        }
        previousLength = segmentEnd;
      }
      return points[points.length - 1];
    }

    resizeCanvas() {
      const bounds = this.world.getBoundingClientRect();
      const scale = window.devicePixelRatio || 1;
      this.canvas.width = Math.max(1, Math.round(bounds.width * scale));
      this.canvas.height = Math.max(1, Math.round(bounds.height * scale));
      this.canvas.style.width = `${bounds.width}px`;
      this.canvas.style.height = `${bounds.height}px`;
      this.context.setTransform(scale, 0, 0, scale, 0, 0);
    }

    render(state) {
      this.lastState = state;
      this.root.dataset.phase = state.phase;
      this.root.classList.toggle('is-paused', state.paused);
      document.getElementById('pauseButton').classList.toggle('has-pauseIcon', this.loadedAssets.has('pauseIcon') && !state.paused);
      this.renderEnemy(state);
      this.renderDoor(state);
      this.renderBed(state);
      this.renderTurrets(state);
      this.renderEffects(state);
    }

    renderEnemy(state) {
      const visible = ['enemy_approaching', 'combat', 'enemy_wounded', 'enemy_retreating', 'victory', 'defeat'].includes(state.phase);
      this.enemy.hidden = !visible;
      if (!visible) return;
      const progress = ['enemy_approaching', 'enemy_wounded', 'enemy_retreating'].includes(state.phase) ? state.enemy.progress : 1;
      const assetKey = state.phase === 'combat' || state.phase === 'defeat'
        ? 'enemyAttackSprite'
        : state.phase === 'victory' ? 'enemyDefeatedSprite' : 'enemySprite';
      this.setWorldPosition(this.enemy, this.getPathPoint(progress));
      this.enemy.classList.toggle('has-art', this.assetAvailable(assetKey));
      this.enemy.style.backgroundImage = this.assetAvailable(assetKey) ? `var(--asset-${assetKey})` : '';
      this.enemy.classList.toggle('is-attacking', state.phase === 'combat');
      this.enemy.classList.toggle('is-wounded', state.phase === 'enemy_wounded');
      this.enemy.classList.toggle('is-retreating', state.phase === 'enemy_retreating');
      this.enemy.classList.toggle('is-defeated', state.phase === 'victory');
    }

    renderDoor(state) {
      const door = document.getElementById('door');
      const ratio = state.door.hp / state.door.maxHp;
      const visualRect = config.world.doorVisual || config.world.door;
      this.setWorldRect(door, visualRect);
      this.setWorldPosition(document.getElementById('doorHealth'), { x: visualRect.x - 2, y: visualRect.y - 34 });
      door.dataset.level = state.door.level;
      const assetKey = `doorLv${Math.min(state.door.level, 3)}`;
      door.dataset.visualLevel = Math.min(state.door.level, 3);
      door.classList.toggle('has-art', this.assetAvailable(assetKey));
      door.classList.toggle('is-hit', state.phase === 'combat' && !state.paused);
      door.style.backgroundImage = this.assetAvailable(assetKey) ? `var(--asset-${assetKey})` : '';
      document.getElementById('doorHealthBar').style.width = `${ratio * 100}%`;
    }

    renderBed(state) {
      const bed = document.getElementById('bed');
      const player = document.querySelector('.player');
      const visualRect = config.world.bedVisual || config.world.bed;
      this.setWorldRect(bed, visualRect);
      bed.dataset.level = state.bed.level;
      const bedAssetKey = `bedLv${Math.min(state.bed.level, 3)}`;
      bed.classList.toggle('has-art', this.assetAvailable(bedAssetKey));
      bed.style.backgroundImage = this.assetAvailable(bedAssetKey) ? `var(--asset-${bedAssetKey})` : '';
      const meditating = state.phase !== 'idle';
      const playerAssetKey = meditating && this.assetAvailable('playerMeditatingCutout')
        ? 'playerMeditatingCutout'
        : 'playerSprite';
      player.classList.toggle('is-meditating', meditating);
      player.classList.toggle('has-art', this.assetAvailable(playerAssetKey));
      player.style.backgroundImage = this.assetAvailable(playerAssetKey) ? `var(--asset-${playerAssetKey})` : '';
    }

    renderTurrets(state) {
      state.turrets.forEach((turret, index) => {
        const slot = document.querySelector(`[data-slot="${index}"]`);
        if (!slot) return;
        const point = config.world.turretSlots[index];
        const auxiliary = state.auxiliaryBuildings[index];
        const occupant = turret || auxiliary;
        const auxiliaryNames = { lamp: '聚灵灯', repair: '镇魂符台', slow: '寒符阵' };
        this.setWorldPosition(slot, point);
        slot.style.width = `${point.size / config.world.width * 100}%`;
        slot.dataset.zone = point.zone;
        slot.classList.toggle('is-built', Boolean(occupant));
        slot.classList.toggle('is-auxiliary', Boolean(auxiliary));
        slot.classList.toggle('has-art', Boolean(turret) && this.assetAvailable(`turretLv${turret.level}`));
        slot.dataset.object = turret ? 'turret' : auxiliary?.type || 'slot';
        slot.dataset.level = occupant ? occupant.level : 0;
        slot.querySelector('span').textContent = '';
        // This is visual-only: the numeric badge makes a built turret legible
        // inside the scene without changing its combat data or behaviour.
        slot.querySelector('small').textContent = turret ? `Lv.${turret.level}` : '';
        slot.setAttribute('aria-label', turret
          ? `镇妖弩 ${index + 1}，等级 ${turret.level}`
          : auxiliary
            ? `${auxiliaryNames[auxiliary.type]} ${index + 1}，等级 ${auxiliary.level}`
            : `空建筑位 ${index + 1}`);
        const turretAssetKey = turret && this.assetAvailable(`turretLv${Math.min(turret.level, 3)}`)
          ? `turretLv${Math.min(turret.level, 3)}`
          : null;
        // CSS combines the supplied stone pedestal with this turret sprite.
        // Keeping the composition in CSS leaves the 9 slot coordinates and
        // all building/combat behaviour untouched.
        slot.style.setProperty('--turret-sprite', turretAssetKey ? `var(--asset-${turretAssetKey})` : 'none');
        slot.style.backgroundImage = '';
      });
    }

    renderEffects(state) {
      const ctx = this.context;
      const bounds = this.world.getBoundingClientRect();
      ctx.clearRect(0, 0, bounds.width, bounds.height);
      if (this.enemy.hidden) return;
      const enemyBounds = this.enemy.getBoundingClientRect();
      const target = {
        x: enemyBounds.left - bounds.left + enemyBounds.width / 2,
        y: enemyBounds.top - bounds.top + enemyBounds.height / 2
      };

      state.effects.forEach((effect) => {
        const sourceNode = document.querySelector(`[data-slot="${effect.slot}"]`);
        if (!sourceNode) return;
        const sourceBounds = sourceNode.getBoundingClientRect();
        const source = {
          x: sourceBounds.left - bounds.left + sourceBounds.width / 2,
          y: sourceBounds.top - bounds.top + sourceBounds.height / 2
        };
        const progress = Math.min(effect.age / effect.duration, 1);
        const x = source.x + (target.x - source.x) * progress;
        const y = source.y + (target.y - source.y) * progress;
        const bolt = this.loadedAssets.get('boltSprite');
        ctx.strokeStyle = 'rgba(255, 224, 122, 0.65)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(source.x, source.y);
        ctx.lineTo(x, y);
        ctx.stroke();
        if (bolt) {
          ctx.drawImage(bolt, x - 8, y - 8, 16, 16);
        } else {
          ctx.fillStyle = '#fff0a8';
          ctx.beginPath();
          ctx.arc(x, y, 4, 0, Math.PI * 2);
          ctx.fill();
        }
        const hit = this.loadedAssets.get('hitEffect');
        if (hit && progress > 0.82) ctx.drawImage(hit, target.x - 16, target.y - 16, 32, 32);
      });
    }
  }

  window.mgdRenderer = new Renderer();
})();
