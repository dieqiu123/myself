(function () {
  'use strict';

  const config = window.GAME_CONFIG;
  const terminalPhases = new Set(['victory', 'defeat']);
  const activePhases = new Set(['preparing', 'enemy_approaching', 'combat', 'enemy_wounded', 'enemy_retreating', 'wave_intermission']);

  function getWaveConfig(wave) {
    return config.enemy.waves[Math.min(wave, config.enemy.waves.length) - 1];
  }

  function createInitialState() {
    return {
      phase: 'idle',
      paused: false,
      spirit: 0,
      incomeAccumulator: 0,
      aura: 0,
      auraAccumulator: 0,
      repairAccumulator: 0,
      preparationRemaining: config.preparationSeconds,
      approachRemaining: config.enemyApproachSeconds,
      enemy: {
        hp: getWaveConfig(1).hp,
        maxHp: getWaveConfig(1).hp,
        progress: 0,
        woundedRemaining: 0,
        retreatRemaining: 0,
        intermissionRemaining: 0,
        lifetimeSeconds: 0,
        damageTaken: 0,
        rewardClaimed: false,
        defeatResolved: false,
        retreatResolved: false
      },
      wave: 1,
      waveResolved: false,
      outcomeResolved: false,
      bed: { level: 1 },
      door: { level: 1, hp: config.door[0].maxHp, maxHp: config.door[0].maxHp },
      turrets: Array.from({ length: config.turretSlotCount }, () => null),
      auxiliaryBuildings: Array.from({ length: config.turretSlotCount }, () => null),
      buildChoice: 'turret',
      selection: { type: 'bed', index: null },
      effects: [],
      diagnostics: {
        engagedSeconds: 0,
        totalDamage: 0,
        dps: 0,
        turrets: Array.from({ length: config.turretSlotCount }, () => ({ attacks: 0, damage: 0 })),
        waves: []
      },
      lastEvent: null,
      revision: 0
    };
  }

  class Game {
    constructor() {
      this.state = createInitialState();
      this.listeners = new Set();
      this.lastFrame = 0;
      this.frameId = 0;
    }

    subscribe(listener) {
      this.listeners.add(listener);
      listener(this.state);
      return () => this.listeners.delete(listener);
    }

    notify(eventName) {
      if (eventName) this.state.lastEvent = eventName;
      this.state.revision += 1;
      this.listeners.forEach((listener) => listener(this.state));
      this.state.lastEvent = null;
    }

    start() {
      if (this.state.phase !== 'idle') return;
      this.state.phase = 'preparing';
      this.notify('started');
      this.lastFrame = performance.now();
      this.frameId = requestAnimationFrame((time) => this.loop(time));
    }

    restart() {
      cancelAnimationFrame(this.frameId);
      this.state = createInitialState();
      this.lastFrame = 0;
      this.frameId = 0;
      this.notify('restarted');
    }

    loop(time) {
      const delta = Math.min((time - this.lastFrame) / 1000, 0.1);
      this.lastFrame = time;
      if (!this.state.paused && activePhases.has(this.state.phase)) this.update(delta);
      this.notify();
      if (!terminalPhases.has(this.state.phase) && this.state.phase !== 'idle') {
        this.frameId = requestAnimationFrame((nextTime) => this.loop(nextTime));
      }
    }

    update(delta) {
      if (terminalPhases.has(this.state.phase)) return;
      this.updateIncome(delta);
      // Experimental auxiliary buildings are intentionally disabled in V0.4-C.
      this.updateDiagnosticsTime(delta);
      if (this.state.phase === 'preparing') this.updatePreparation(delta);
      if (this.state.phase === 'enemy_approaching') this.updateApproach(delta);
      if (this.state.phase === 'combat') this.updateCombat(delta);
      if (this.state.phase === 'enemy_wounded') this.updateWounded(delta);
      if (this.state.phase === 'enemy_retreating') this.updateRetreat(delta);
      if (this.state.phase === 'wave_intermission') this.updateIntermission(delta);
      if (['enemy_approaching', 'combat', 'enemy_wounded', 'enemy_retreating'].includes(this.state.phase)) this.updateTurrets(delta);
      this.updateEffects(delta);
      this.resolveOutcome();
    }

    updateDiagnosticsTime(delta) {
      if (!['enemy_approaching', 'combat', 'enemy_wounded', 'enemy_retreating'].includes(this.state.phase)) return;
      this.state.enemy.lifetimeSeconds += delta;
      const hasEngagedTurret = this.state.turrets.some((turret, index) => (
        turret && this.state.enemy.progress >= this.getTurretZoneConfig(index).rangeProgress
      ));
      if (!hasEngagedTurret) return;
      const diagnostics = this.state.diagnostics;
      diagnostics.engagedSeconds += delta;
      diagnostics.dps = diagnostics.engagedSeconds > 0 ? diagnostics.totalDamage / diagnostics.engagedSeconds : 0;
    }

    updateIncome(delta) {
      this.state.incomeAccumulator += delta * config.bed[this.state.bed.level - 1].income;
      const earned = Math.floor(this.state.incomeAccumulator);
      if (earned > 0) {
        this.state.spirit += earned;
        this.state.incomeAccumulator -= earned;
        this.state.lastEvent = 'income';
      }
    }

    getAuraIncome() {
      return 0;
    }

    updateAuxiliaryBuildings(delta) {
      return;
    }

    getEnemySpeedMultiplier() {
      return 1;
    }

    getCurrentWaveConfig() {
      return getWaveConfig(this.state.wave);
    }

    getEnemyMovementRate() {
      return this.getCurrentWaveConfig().moveSpeedMultiplier * this.getEnemySpeedMultiplier();
    }

    getTurretZoneConfig(index) {
      return { rangeProgress: config.enemy.turretRangeProgress, damageMultiplier: 1 };
    }

    updatePreparation(delta) {
      this.state.preparationRemaining = Math.max(0, this.state.preparationRemaining - delta);
      if (this.state.preparationRemaining === 0) {
        this.state.phase = 'enemy_approaching';
        this.state.lastEvent = 'enemy_spawned';
      }
    }

    updateApproach(delta) {
      const movementDelta = delta * this.getEnemyMovementRate();
      this.state.approachRemaining = Math.max(0, this.state.approachRemaining - movementDelta);
      this.state.enemy.progress = 1 - this.state.approachRemaining / config.enemyApproachSeconds;
      if (this.state.approachRemaining === 0) {
        this.state.enemy.progress = 1;
        this.state.phase = 'combat';
        this.state.lastEvent = 'combat_started';
      }
    }

    updateCombat(delta) {
      this.state.door.hp = Math.max(0, this.state.door.hp - this.getCurrentWaveConfig().doorDamagePerSecond * delta);
    }

    updateWounded(delta) {
      this.state.enemy.woundedRemaining = Math.max(0, this.state.enemy.woundedRemaining - delta);
      if (this.state.enemy.woundedRemaining <= 0.001) {
        this.state.enemy.woundedRemaining = 0;
        this.state.phase = 'enemy_retreating';
        this.state.enemy.retreatRemaining = this.state.enemy.progress * config.enemyApproachSeconds / config.enemy.retreatSpeedMultiplier;
        this.state.lastEvent = 'enemy_retreating';
      }
    }

    updateRetreat(delta) {
      const enemy = this.state.enemy;
      const movementDelta = delta * this.getEnemyMovementRate();
      enemy.retreatRemaining = Math.max(0, enemy.retreatRemaining - movementDelta);
      enemy.progress = Math.max(0, enemy.retreatRemaining * config.enemy.retreatSpeedMultiplier / config.enemyApproachSeconds);
      if (enemy.retreatRemaining === 0) {
        this.completeWave('enemy_retreated', config.enemy.retreatReward);
      }
    }

    updateIntermission(delta) {
      const enemy = this.state.enemy;
      enemy.intermissionRemaining = Math.max(0, enemy.intermissionRemaining - delta);
      if (enemy.intermissionRemaining !== 0) return;
      this.state.wave += 1;
      const waveConfig = this.getCurrentWaveConfig();
      enemy.hp = waveConfig.hp;
      enemy.maxHp = waveConfig.hp;
      enemy.progress = 0;
      enemy.woundedRemaining = 0;
      enemy.retreatRemaining = 0;
      enemy.lifetimeSeconds = 0;
      enemy.damageTaken = 0;
      enemy.rewardClaimed = false;
      enemy.defeatResolved = false;
      enemy.retreatResolved = false;
      this.state.waveResolved = false;
      this.state.approachRemaining = config.enemyApproachSeconds;
      this.state.phase = 'enemy_approaching';
      this.state.lastEvent = 'next_wave_started';
    }

    updateTurrets(delta) {
      this.state.turrets.forEach((turret, index) => {
        if (!turret) return;
        if (!['enemy_approaching', 'combat', 'enemy_wounded', 'enemy_retreating'].includes(this.state.phase)) return;
        const zone = this.getTurretZoneConfig(index);
        if (this.state.enemy.progress < zone.rangeProgress) return;
        turret.cooldown -= delta;
        if (turret.cooldown > 0 || this.state.enemy.hp <= 0) return;
        const stats = config.turret[turret.level - 1];
        turret.cooldown += stats.interval;
        const hpBefore = this.state.enemy.hp;
        this.state.enemy.hp = Math.max(0, hpBefore - stats.attack * zone.damageMultiplier);
        const actualDamage = hpBefore - this.state.enemy.hp;
        const turretStats = this.state.diagnostics.turrets[index];
        turretStats.attacks += 1;
        turretStats.damage += actualDamage;
        this.state.diagnostics.totalDamage += actualDamage;
        this.state.enemy.damageTaken += actualDamage;
        this.state.diagnostics.dps = this.state.diagnostics.engagedSeconds > 0
          ? this.state.diagnostics.totalDamage / this.state.diagnostics.engagedSeconds
          : 0;
        this.state.effects.push({ type: 'bolt', slot: index, age: 0, duration: 0.22 });
        this.state.lastEvent = 'turret_fired';
        this.enterWoundedState();
      });
    }

    enterWoundedState() {
      const enemy = this.state.enemy;
      const isFinalWave = this.state.wave >= config.enemy.waveCount;
      const canRetreat = ['enemy_approaching', 'combat'].includes(this.state.phase);
      if (isFinalWave || !canRetreat || enemy.hp > enemy.maxHp * config.enemy.woundedThreshold) return;
      this.state.phase = 'enemy_wounded';
      enemy.woundedRemaining = config.enemy.woundedFeedbackSeconds;
      this.state.lastEvent = 'enemy_wounded';
    }

    completeWave(eventName, reward) {
      const enemy = this.state.enemy;
      if (this.state.waveResolved || enemy.rewardClaimed) return false;
      this.state.waveResolved = true;
      enemy.rewardClaimed = true;
      enemy.retreatResolved = eventName === 'enemy_retreated';
      enemy.defeatResolved = eventName === 'enemy_killed';
      this.state.spirit += reward;
      this.recordWaveResult(eventName);
      enemy.progress = 0;
      enemy.woundedRemaining = 0;
      enemy.retreatRemaining = 0;
      enemy.intermissionRemaining = config.enemy.waveIntermissionSeconds;
      this.state.phase = 'wave_intermission';
      this.state.lastEvent = eventName;
      return true;
    }

    recordWaveResult(result) {
      const enemy = this.state.enemy;
      this.state.diagnostics.waves.push({
        wave: this.state.wave,
        result,
        survivalSeconds: enemy.lifetimeSeconds,
        damageTaken: enemy.damageTaken
      });
    }

    updateEffects(delta) {
      this.state.effects.forEach((effect) => { effect.age += delta; });
      this.state.effects = this.state.effects.filter((effect) => effect.age < effect.duration);
    }

    resolveOutcome() {
      if (this.state.outcomeResolved) return;
      if (this.state.enemy.hp <= 0 && !terminalPhases.has(this.state.phase)) {
        if (this.state.wave >= config.enemy.waveCount) {
          this.state.waveResolved = true;
          this.state.outcomeResolved = true;
          this.state.enemy.rewardClaimed = true;
          this.state.enemy.defeatResolved = true;
          this.recordWaveResult('victory');
          this.state.phase = 'victory';
          this.notify('victory');
        } else if (!this.state.waveResolved) {
          this.completeWave('enemy_killed', config.enemy.killReward);
        }
      } else if (this.state.door.hp <= 0 && !terminalPhases.has(this.state.phase)) {
        this.state.waveResolved = true;
        this.state.outcomeResolved = true;
        this.recordWaveResult('defeat');
        this.state.phase = 'defeat';
        this.notify('defeat');
      }
    }

    select(type, index) {
      this.state.selection = { type, index: index ?? null };
      this.notify('selection_changed');
    }

    performSelectedAction() {
      const { type, index } = this.state.selection;
      if (this.state.phase === 'idle') {
        if (type === 'bed') this.start();
        else this.notify('must_meditate');
        return;
      }
      if (terminalPhases.has(this.state.phase) || this.state.paused) return;
      if (type === 'bed') this.upgradeBed();
      if (type === 'door') this.upgradeDoor();
      if (type === 'slot') this.buildSelected(index);
      if (type === 'turret') this.upgradeTurret(index);
    }

    spend(cost) {
      if (this.state.spirit < cost) {
        this.notify('insufficient_spirit');
        return false;
      }
      this.state.spirit -= cost;
      return true;
    }

    spendAura(cost) {
      return false;
    }

    setBuildChoice(type) {
      if (type !== 'turret') return;
      this.state.buildChoice = 'turret';
    }

    getSlotSelectionType(index) {
      if (this.state.turrets[index]) return 'turret';
      return 'slot';
    }

    isSlotOccupied(index) {
      return Boolean(this.state.turrets[index]);
    }

    buildSelected(index) {
      return this.buildTurret(index);
    }

    upgradeBed() {
      const current = config.bed[this.state.bed.level - 1];
      if (current.upgradeCost == null) return this.notify('max_level');
      if (!this.spend(current.upgradeCost)) return;
      this.state.bed.level += 1;
      this.notify('bed_upgraded');
    }

    upgradeDoor() {
      const current = config.door[this.state.door.level - 1];
      if (current.upgradeCost == null) return this.notify('max_level');
      if (!this.spend(current.upgradeCost)) return;
      this.state.door.level += 1;
      const upgraded = config.door[this.state.door.level - 1];
      this.state.door.maxHp = upgraded.maxHp;
      this.state.door.hp = upgraded.maxHp;
      this.notify('door_upgraded_full');
    }

    buildTurret(index) {
      if (this.isSlotOccupied(index)) return;
      if (!this.spend(config.turretBuildCost)) return;
      this.state.turrets[index] = { level: 1, cooldown: 0.15 };
      this.state.selection = { type: 'turret', index };
      this.notify('turret_built');
    }

    buildAuxiliary(index, type) {
      if (this.isSlotOccupied(index)) return;
      if (type !== 'lamp' && this.state.auxiliaryBuildings.some((building) => building?.type === type)) {
        this.notify('unique_building_exists');
        return;
      }

      const definition = config.auxiliary[type];
      const paid = type === 'lamp'
        ? this.spend(definition.buildCost)
        : this.spendAura(definition.buildCost);
      if (!paid) return;

      this.state.auxiliaryBuildings[index] = { type, level: 1 };
      this.state.selection = { type, index };
      this.notify(`${type}_built`);
    }

    upgradeLamp(index) {
      const lamp = this.state.auxiliaryBuildings[index];
      if (!lamp || lamp.type !== 'lamp') return;
      const current = config.auxiliary.lamp.levels[lamp.level - 1];
      if (current.upgradeCost == null) return this.notify('max_level');
      if (!this.spend(current.upgradeCost)) return;
      lamp.level += 1;
      this.notify('lamp_upgraded');
    }

    upgradeTurret(index) {
      const turret = this.state.turrets[index];
      if (!turret) return;
      const current = config.turret[turret.level - 1];
      if (current.upgradeCost == null) return this.notify('max_level');
      if (!this.spend(current.upgradeCost)) return;
      turret.level += 1;
      turret.cooldown = Math.min(turret.cooldown, config.turret[turret.level - 1].interval);
      this.notify('turret_upgraded');
    }

    togglePause() {
      if (!activePhases.has(this.state.phase)) return;
      this.state.paused = !this.state.paused;
      this.lastFrame = performance.now();
      this.notify(this.state.paused ? 'paused' : 'resumed');
    }
  }

  window.mgdGame = new Game();
})();
